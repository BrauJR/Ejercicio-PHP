<?php
// Comentario de una sola linea
/*
Comentario de varias 
linea
*/

// IMPRIMIR EN PANTALLA
echo "Hola Mundo";
echo "<br/> Hola buen mundo <br/> estoy <h1>aprendiendo PHP</h1>"; 

// TRATAMIENTO DE VARIABLES
$nombre = "Jonathan";
$Nombre = "Ulises";

// CONCATENACIÓN DE CADENAS Y VARIABLES
echo $nombre."&nbsp;".$Nombre;
echo "<br/>";

$num1 = 5;
$num2 = 77;
$suma = $num1 + $num2;
echo $suma;

echo "<br/> La variable \$suma tiene el valor de $suma";

// CICLOS
// if
$modulo = $num2 % 2;
echo "<br/> ";
if($modulo == 0) {
 echo "El número es PAR";
} else {
 echo "El número es IMPAR";
}

// for
echo "<br/>";
for($i = 0; $i <= 10; $i++) {
 echo $i."<br/>";
}

?>