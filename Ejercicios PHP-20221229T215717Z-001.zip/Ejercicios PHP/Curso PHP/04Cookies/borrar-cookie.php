<?php
 setcookie("idioma_solicitado", "", time()-1, "/");
?>
<a href="usar-cookie.php"> REGRESAR </a>