<?php
 session_start();
 // Evaluo que la sesión continue verificando una de las variables creada en control.php, cuando ya no coincida con su valor incicial se redirihe al archivo salir.php
 if(!$_SESSION["autentificado"]) {
    header("Location: salir.php");
 }
?>