<?php
function conectarse() {
    $servidor = "localhost";
    $usuario = "root";
    $password = "";
    $bd = "foro";

    $conectar = new mysqli($servidor, $usuario, $password, $bd);
    return $conectar;
}

$conexion = conectarse();

/*
if($conexion) {
    echo "<span>BD YEAAAA</span>";
}
*/
?>