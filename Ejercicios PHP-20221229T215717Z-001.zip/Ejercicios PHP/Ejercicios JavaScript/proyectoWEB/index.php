<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foro de discusión</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Nerko+One&family=Sniglet&display=swap"
        rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Nerko+One&family=Sniglet&display=swap"
        rel="stylesheet">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Acme&family=Nerko+One&family=Sniglet&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Acme&family=Nerko+One&family=Sniglet&display=swap');

        h1 {
            font-family: 'Acme', sans-serif;
            font-family: 'Nerko One', cursive;
            font-family: 'Sniglet', cursive;
        }

        header {
            background-color: bisque;
            padding: 0;
            height: 90px;
        }

        .titulo {
            text-align: center;
            background-color: bisque;
            display: flex;
            justify-content: center;
        }

        form {
            font-family: 'Acme', sans-serif;
            font-family: 'Nerko One', cursive;
            font-family: 'Sniglet', cursive;
            line-height: 60px;
            width: 80%;
            padding: 10px;
        }

        fieldset {
            border: .2em solid bisque;
            border-radius: .5em;
            padding: 1em;
            font-size: larger;
        }

        input[type="date"],
        input[type="email"],
        input[type="number"],
        input[type="text"] {
            background: #EEE;
            border-radius: .25em;
            font-size: 1em;
            padding: .25em;
        }

        textarea {
            background: #EEE;
            border-radius: .25em;
            font-size: 1em;
            padding: .25em;
        }

        input[type="submit"] {
            background: #FF9A55;
            border-color: #FF9A55;
            border-radius: 30px;
            font-size: 1em;
            cursor: pointer;
            padding: 7px;
        }

        input[type="submit"]:hover {
            background: white;
            border-color: #FF9A55;
            border-radius: 30px;
            font-size: 1em;
            cursor: pointer;
            padding: 7px;
            transition: .9s;
        }

        .contenido {
            display: grid;
            gap: 1em;
            grid-template-areas: 'a b';
            height: 100vh;
        }

        .a {
            grid-area: a;
            justify-content: center;
            align-items: center;
            justify-self: center;
        }

        .b {
            grid-area: b;
            font-family: 'Acme', sans-serif;
            font-family: 'Nerko One', cursive;
            font-family: 'Sniglet', cursive;
            border: .2em solid bisque;
            padding: 10px;
            text-align: center;
        }

        .posicionBoton {
            display: flex;
            justify-content: center;
            padding: 5x;
        }

        table {
            border-collapse: separate;
            border-spacing: 5px;
            background-color:#FF9A55;
            color: white;
            width: 100%;
        }

        td, th {
            background: #fff;
            color: #000;
        }
    </style>
</head>

<body>
    <header>
        <div class="titulo">
            <h1>Foro de discusión</h1>
        </div>
    </header>

    <div class="contenido">
        <div class="a">
            <form action="agregar-comentario.php" name="foro_frm" method="post" enctype="multipart/form-data">
                <fieldset>
                    <legend>Comentario</legend>
                    <div>
                        <label for="clave">ID del comentario &nbsp;</label>
                        <input type="email" id="clave" name="clave_txt" placeholder="Ingrese su email" title="Clave" required>
                    </div>
                    <div>
                        <textarea name="textarea_txt" rows="10" cols="50" placeholder="Escribe tu comentario"
                            required></textarea>
                    </div>
                    <div>
                        <label for="fecha">Selecciona la fecha &nbsp;</label>
                        <input type="date" id="fecha" name="fecha_txt" title="Fecha" required>
                    </div>
                    <div class="posicionBoton">
                        <input type="submit" id="enviar" name="enviar_btn" value="Agregar comentario">
                    </div>
                </fieldset>
            </form>
        </div>
        <div class="b">
            <h1>Historial de comentarios</h1>
            <center>
        <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Marca</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
include "conexion.php";
$query = "SELECT * FROM comentario";
$result = mysqli_query($conexion, $query);
while ($row = mysqli_fetch_array($result)) {
    #Obtiene una fila de resultados como un array asociativo, numérico, o ambos
    ?>
                            <tr>
                                <td><?php echo $row['idComentario'] ?></td>
                                <td><?php echo $row['Marca'] ?></td>
                                <td><?php echo $row['Fecha'] ?></td>

                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                    </center>
        </div>
    </div>
</body>

</html>