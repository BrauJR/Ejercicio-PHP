<?php
// Asigno a variables PHP las variables que vienen del formulario
$id = $_POST["clave_txt"];
$comentario = $_POST["textarea_txt"];
$fecha = $_POST["fecha_txt"];

include("conexion.php");
$consulta = "INSERT INTO comentario(idComentario,Marca,Fecha) VALUES ('$id ','$comentario','$fecha')";
$ejecutar_consulta = $conexion->query($consulta);

if($ejecutar_consulta) {
    echo "<b>Se agreg</b>";
} else {
    echo "<b>No se agreg</b>";
}

$conexion->close();
header("Location: index.php")
?>